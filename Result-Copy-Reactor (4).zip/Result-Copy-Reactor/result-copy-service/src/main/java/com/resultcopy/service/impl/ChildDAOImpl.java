package com.resultcopy.service.impl;

import com.resultcopy.service.ConnectionFactory;
import com.resultcopy.service.dao.ChildDAO;
import com.resultcopy.service.dao.PatientDAO;
import com.resultcopy.service.model.Child;
import com.resultcopy.service.model.Patient;
import com.resultcopy.service.model.PatientDetails;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ChildDAOImpl implements ChildDAO {

    @Override
    public List<PatientDetails> getPatientById(Integer patientId) {

        Patient patient = null;
        PatientDetails pd = null;
        List<PatientDetails> childDetails = new ArrayList<>();
        Child child = new Child();
        Connection con = ConnectionFactory.getConnection();
        String sql = "SELECT c.child_id ,c.first_name,c.last_name,c.mrn,c.fin FROM patient p ,Child c WHERE p.PATIENT_ID = c.Patient_Id  AND p.PATIENT_ID = "+patientId;
        System.out.println("SQL :"+sql);
        try{
            PreparedStatement pStmt = con.prepareStatement(sql);
            ResultSet rs = pStmt.executeQuery();

            while (rs.next()) {
                pd= new PatientDetails();
                pd.setId(rs.getInt("CHILD_ID"));
                pd.setFirstName(rs.getString("FIRST_NAME"));
                pd.setLastName(rs.getString("LAST_NAME"));
                pd.setMrn(rs.getString("MRN"));
                pd.setFin(rs.getString("FIN"));
                childDetails.add(pd);
            }
            patient = new Patient();
            patient.setPatientDetails(pd);
        }catch (SQLException ex){
            ex.printStackTrace();
        }

        child.setChildDetails(childDetails);
        return childDetails;
    }


    public static  void main(String args){
        ChildDAOImpl impl = new ChildDAOImpl();
        impl.getPatientById(1);
    }
}
