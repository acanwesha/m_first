package com.resultcopy.service.dao;


import com.resultcopy.service.model.Patient;

public interface PatientDAO {

    Patient getPatientById(Integer patientId);
}
