package com.resultcopy.service.serviceimpl;

import com.resultcopy.ChildDto;
import com.resultcopy.PatientDto;
import com.resultcopy.PatientResultDto;
import com.resultcopy.service.dao.BabyResultDAO;
import com.resultcopy.service.dao.ChildDAO;
import com.resultcopy.service.impl.BabyResultDAOImpl;
import com.resultcopy.service.impl.ChildDAOImpl;
import com.resultcopy.service.impl.PatientDAOImpl;
import com.resultcopy.service.model.BabyResult;
import com.resultcopy.service.model.Patient;
import com.resultcopy.service.model.PatientDetails;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PatientServiceImpl {

    public PatientResultDto getPatientDetails(String patientId){
        PatientDAOImpl dao = new PatientDAOImpl();
        Patient p =dao.getPatientById(Integer.parseInt(patientId));
        PatientDto pDto = new PatientDto();
        pDto.setPatientId(p.getPatientDetails().getId());
        pDto.setFin(p.getPatientDetails().getFin());
        pDto.setFirstName(p.getPatientDetails().getFirstName());
        pDto.setLastName(p.getPatientDetails().getLastName());
        pDto.setMrn(p.getPatientDetails().getMrn());

        ChildDAO childDAO = new ChildDAOImpl() ;
        List<PatientDetails> patientDetailsList = childDAO.getPatientById(Integer.parseInt(patientId));

        PatientDto childDetails  = null;
        //List<PatientDto> childDetailsList = new ArrayList<>();

        ChildDto childDto = null;
        List<ChildDto> childDtoList = new ArrayList<>();
        BabyResultDAO babyResultDAO = new BabyResultDAOImpl();
        for(PatientDetails patientDetail:patientDetailsList){
            childDto = new ChildDto();
            childDto.setFin(patientDetail.getFin());
            childDto.setChildId(patientDetail.getId());
            childDto.setFirstName(patientDetail.getFirstName());
            childDto.setLastName(patientDetail.getLastName());
            childDto.setMrn(patientDetail.getMrn());

            BabyResult br = babyResultDAO.getBabyPatientByChildId(childDto.getChildId());

            //if copied
            if(null!=br){
                childDto.setResultCopiedDate(br.getDateTime());
            }else{ //if not copied

            }

            childDtoList.add(childDto);
        }

        PatientResultDto patient = new PatientResultDto();
        patient.setPatient(pDto);
        patient.setChild(childDtoList);

        return patient;
    }
}
