package com.resultcopy;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ResultDto implements Serializable {
    private Integer resultId;
    private String resultName;
    private String value;
}
